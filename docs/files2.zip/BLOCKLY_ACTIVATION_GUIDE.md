# How to Activate Blockly Configuration from the IDE

## What I Added ✅

I've integrated the Blockly configuration dialog into your IDE menu system!

### Changes Made:

**File: `core/ide_window.py`**

1. **Added Import** (line 23):
```python
from dialogs.blockly_config_dialog import BlocklyConfigDialog
```

2. **Added Menu Item** (in Tools menu, ~line 233):
```python
tools_menu.addAction(self.create_action(
    self.tr("Configure &Blockly Blocks..."), 
    None, 
    self.configure_blockly
))
```

3. **Added Method** (after show_asset_manager, ~line 1779):
```python
def configure_blockly(self):
    """Open Blockly configuration dialog to customize available blocks"""
    from config.blockly_config import load_config, save_config
    
    # Load current configuration
    current_config = load_config()
    
    # Show dialog
    dialog = BlocklyConfigDialog(self, current_config)
    if dialog.exec() == QDialog.Accepted:
        # Save the new configuration
        new_config = dialog.config
        save_config(new_config)
        
        # Show confirmation
        QMessageBox.information(
            self,
            self.tr("Configuration Saved"),
            self.tr("Blockly configuration has been saved...")
        )
```

## How to Use

### Step 1: Access from Menu

Open PyGameMaker IDE and go to:

```
Tools → Configure Blockly Blocks...
```

Or use the keyboard shortcut: `Alt+T`, then `B`

### Step 2: Choose a Preset

The dialog opens with a dropdown at the top:

**Presets:**
- **Full (All Blocks)** - All 60+ blocks available
- **Beginner (Basic Blocks)** - 15 essential blocks only
- **Intermediate (More Features)** - 30+ blocks
- **Platformer Game** - Physics-focused blocks
- **Grid-based RPG** - Turn-based game blocks
- **Custom** - Manual selection

Select the preset that matches your needs.

### Step 3: Customize (Optional)

Below the preset dropdown, you'll see a tree view:

```
☑ Events
  ☑ Create Event
  ☑ Step Event
  ☐ Draw Event
  ☑ Destroy Event
  ...
☑ Movement
  ☑ Set Horizontal Speed
  ☑ Set Vertical Speed
  ...
```

**To customize:**
- Check/uncheck individual blocks
- Check/uncheck entire categories
- System warns about missing dependencies

### Step 4: Save

Click **OK** to save your configuration.

You'll see a confirmation:
```
✅ Blockly configuration saved!

The new block selection will be available
the next time you open an object editor.
```

### Step 5: Use in Object Editor

1. Open any object (or create new one)
2. Go to "Visual Programming" tab
3. **Only the blocks you enabled will appear!**

The Blockly toolbox now shows only your selected blocks.

## Example Workflows

### For Teaching Programming

**Goal:** Keep interface simple for beginners

**Steps:**
1. Tools → Configure Blockly Blocks
2. Select "Beginner (Basic Blocks)"
3. Click OK
4. Students now see only essential blocks

**Result:**
- Create, Step events
- Basic movement
- Simple score system
- No overwhelming advanced features

### For Specific Game Types

**Goal:** Show only relevant blocks for platformer

**Steps:**
1. Tools → Configure Blockly Blocks
2. Select "Platformer Game"
3. Click OK

**Result:**
- Physics blocks (gravity, friction)
- Smooth movement
- Lives and score
- No grid-based movement blocks

### Progressive Learning

**Week 1:**
```
Tools → Configure Blockly Blocks → Beginner
```

**Week 4:**
```
Tools → Configure Blockly Blocks → Intermediate
```

**Week 8:**
```
Tools → Configure Blockly Blocks → Full
```

**Result:** Students gradually see more features as they learn.

### Custom Lesson Plan

**Goal:** Students should only use specific blocks for assignment

**Steps:**
1. Tools → Configure Blockly Blocks
2. Select "Custom"
3. Uncheck all categories
4. Manually enable only:
   - Create Event
   - Step Event
   - Set Horizontal Speed
   - Set Vertical Speed
   - Show Message
5. Click OK

**Result:** Students can only use the exact blocks you specified.

## Configuration Persistence

Your configuration is saved to:
```
~/.config/pygamemaker/blockly_config.json
```

**This means:**
- Settings persist across IDE restarts
- Each user has their own configuration
- No need to reconfigure every time

## Checking Current Configuration

**From Console:**
When you save, you'll see:
```
✅ Blockly configuration updated: beginner preset
   Enabled blocks: 15
   Enabled categories: Events, Movement, Output
```

**From Python:**
```python
from config.blockly_config import load_config

config = load_config()
print(f"Preset: {config.preset_name}")
print(f"Blocks: {len(config.enabled_blocks)}")
print(f"Categories: {config.enabled_categories}")
```

## Troubleshooting

### Dialog doesn't open
**Check:** Is `dialogs/blockly_config_dialog.py` in your project?
**Fix:** Make sure all files are synced from GitHub/Dropbox

### Changes don't appear
**Issue:** Configuration is loaded when object editor opens
**Fix:** Close and reopen the object editor to see changes

### Missing dependencies warning
**What it means:** You enabled a block that requires another block
**Example:** "Draw Score" needs "Set Score" and "Add to Score"
**Fix:** Enable the required blocks or disable the dependent block

## Benefits

### For Students:
✅ Focused, uncluttered interface
✅ Learn at appropriate pace
✅ Less overwhelming
✅ Progressive skill building

### For Teachers:
✅ Control feature access
✅ Match curriculum
✅ Prevent confusion
✅ Tailor to lesson plans

### For Game Developers:
✅ Genre-specific toolsets
✅ Faster workflow
✅ Less clutter
✅ Professional presets

## Advanced: Creating Custom Presets

If you want to create your own presets programmatically:

```python
from config.blockly_config import BlocklyConfig, save_config

# Create custom configuration
config = BlocklyConfig(preset_name="my_custom")

# Enable specific blocks
config.enable_block("event_create")
config.enable_block("event_step")
config.enable_block("move_set_hspeed")

# Or enable entire categories
config.enable_category("Movement")
config.enable_category("Sound")

# Save
save_config(config)
```

## Summary

**To activate:**
1. Download updated `ide_window.py`
2. Replace in `core/ide_window.py`
3. Restart IDE
4. Go to Tools → Configure Blockly Blocks

**What you get:**
- ✅ Full GUI configuration
- ✅ 5 presets ready to use
- ✅ Custom block selection
- ✅ Persistent settings
- ✅ Dependency tracking

**Download:**
- [ide_window.py](computer:///mnt/user-data/outputs/ide_window.py) - Updated with Blockly menu integration

The system is now fully activated and ready to use! 🎉
